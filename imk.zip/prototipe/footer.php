  <!-- Footer Start -->
  <footer class="footer-section">
    <div class="row margin-0">

      <div class="col-md-8 column-one">
        <p style="padding-left:30px;">
          <b>Sistem Informasi Monitoring Fasilitas dan Properti Berbasis Web</b><br />
          Kelas: Interaksi Manusia dan Komputer - 6<br />
          Dosen: Anna Dara Andriana., S.Kom., M.Kom.<br />
          Universitas Komputer Indonesia<br /><br />
          Copyright &copy; 2017 KaRuNIA all right reserved.
        </p>
      </div>
      <div class="col-md-4 uipasta-credit pattern-bg column-two">
        <h1>KaRuNIA</h1>
        <ul>
          <li>Keen IO</li>
          <li>NiceAdmin</li>
          <li>WeSoon</li>
        </ul>
      </div>
    </div>
  </footer>
  <!-- Footer End -->

  <!-- Back to Top Start -->
  <a href="#" class="scroll-to-top"><i class="fa fa-long-arrow-up"></i></a>
  <!-- Back to Top End -->

  <!-- All Javascript Plugins  -->
  <script type="text/javascript" src="src/wesoon/js/jquery.min.js"></script>
  <script type="text/javascript" src="src/wesoon/js/plugin.js"></script>
  <!-- Main Javascript File  -->
  <script type="text/javascript" src="src/wesoon/js/scripts.js"></script>
</body>
</html>
