<!-- javascripts -->
<script src="src/niceadmin/js/jquery.js"></script>
<script src="src/niceadmin/js/jquery-ui-1.10.4.min.js"></script>
<script src="src/niceadmin/js/jquery-1.8.3.min.js"></script>
<script src="src/niceadmin/js/jquery-ui-1.9.2.custom.min.js" type="text/javascript"></script>
<!-- bootstrap -->
<script src="src/niceadmin/js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="src/niceadmin/js/jquery.scrollTo.min.js"></script>
<script src="src/niceadmin/js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- charts scripts -->
<script src="src/niceadmin/assets/jquery-knob/js/jquery.knob.js"></script>
<script src="src/niceadmin/js/jquery.sparkline.js" type="text/javascript"></script>
<script src="src/niceadmin/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
<script src="src/niceadmin/js/owl.carousel.js"></script>
<!-- jQuery full calendar -->
<script src="src/niceadmin/js/fullcalendar.min.js"></script>
<!-- Full Google Calendar - Calendar -->
<script src="src/niceadmin/assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
<!--script for this page only-->
<script src="src/niceadmin/js/calendar-custom.js"></script>
<script src="src/niceadmin/js/jquery.rateit.min.js"></script>
<!-- custom select -->
<script src="src/niceadmin/js/jquery.customSelect.min.js"></script>
<script src="src/niceadmin/assets/chart-master/Chart.js"></script>

<!--custome script for all page-->
<script src="src/niceadmin/js/scripts.js"></script>
