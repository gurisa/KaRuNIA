<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="img/favicon.png" rel="shortcut icon">
<link href="src/niceadmin/css/bootstrap.min.css" rel="stylesheet">
<link href="src/niceadmin/css/bootstrap-theme.css" rel="stylesheet">
<link href="src/niceadmin/css/elegant-icons-style.css" rel="stylesheet" />
<link href="src/niceadmin/css/font-awesome.min.css" rel="stylesheet" />
<link href="src/niceadmin/assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
<link href="src/niceadmin/assets/fullcalendar/fullcalendar/fullcalendar.css" rel="stylesheet" />
<link href="src/niceadmin/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen" />
<link href="src/niceadmin/css/owl.carousel.css" class=""rel="stylesheet"  type="text/css">
<link href="src/niceadmin/css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
<link href="src/niceadmin/css/fullcalendar.css" rel="stylesheet">
<link href="src/niceadmin/css/widgets.css" rel="stylesheet">
<link href="src/niceadmin/css/style.css" rel="stylesheet">
<link href="src/niceadmin/css/style-responsive.css" rel="stylesheet" />
<link href="src/niceadmin/css/xcharts.min.css" rel=" stylesheet">
<link href="src/niceadmin/css/jquery-ui-1.10.4.min.css" rel="stylesheet">
<!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
<!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <script src="js/respond.min.js"></script>
  <script src="js/lte-ie7.js"></script>
<![endif]-->
