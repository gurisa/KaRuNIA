<!--sidebar start-->
<aside>
  <div id="sidebar" class="nav-collapse ">
    <!-- sidebar menu start-->
    <ul class="sidebar-menu">
      <li class="active">
        <a class="" href="dashboard.php">
          <i class="icon_house_alt"></i>
          <span>Beranda</span>
        </a>
      </li>
      <li class="sub-menu">
        <a class="" href="profile.php">
          <i class="icon_profile"></i>
          <span>Profil</span>
        </a>
      </li>
      <li class="sub-menu">
        <a class="" href="messages.php">
          <i class="icon_mail_alt"></i>
          <span>Pesan</span>
        </a>
      </li>
      <li class="sub-menu">
        <a class="" href="gallery.php">
          <i class="icon_desktop"></i>
          <span>Galeri</span>
        </a>
      </li>
      <li>
        <a class="" href="report.php">
          <i class="icon_piechart"></i>
          <span>Laporan</span>
        </a>
      </li>
      <li>
        <a class="" href="administrator.php">
          <i class="icon_genius"></i>
          <span>Administrator</span>
        </a>
      </li>      
    </ul>
    <!-- sidebar menu end-->
  </div>
</aside>
<!--sidebar end-->
