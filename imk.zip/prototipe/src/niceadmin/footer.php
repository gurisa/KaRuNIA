<div style="margin:15px;">
  <h1>KaRuNIA</h1>
  Copyright &copy; 2017 KaRuNIA all right reserved.<br />
  <span>Licensed: Keen IO, NiceAdmin, WeSoon</span>
</div>
