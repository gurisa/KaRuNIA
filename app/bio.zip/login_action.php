<?php 
	include('koneksi.php');
	session_start();

	$user = $_POST['username'];
	$pass = $_POST['password'];

	$cari = mysql_query("SELECT * FROM user where username = '$user' and password ='$pass' ");
	if (mysql_num_rows($cari) != 0) {
		$_SESSION['username']=$user;
		header('location:dashboard.php');
	}

	else {
		echo"Akun tidak terdaftar";
		echo "<a href=index.php> Back </a>";
	}

 ?>