function Submit() {
	if (document.xform.username.value == "") {
 		alert("Username Harus Diisi!!");
 		document.xform.username.focus();
 		return false;
 	}

 	if (document.xform.password.value == "") {
 		alert("Password Harus Diisi!!");
 		document.xform.password.focus();
 		return false;
 	}
}