<?php 
	include('koneksi.php');
	session_start();
	if (empty($_SESSION['username'])) {
		header("location:index.php");
	}
 ?> 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	Selamat Datang Di Halaman Dashboard <br> <br><br>

	 Klik Me to <a href="logout.php">Logout</a> <br>
	 Klik Me to <a href="gallery.php"> Gallery Photo</a>
</body>
</html>