<?php 
	include('koneksi.php');
	session_start();
	if (isset($_SESSION['username'])) {
		header("location:dashboard.php");
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Login | Karunia</title>
	<link rel="stylesheet" href="stylelogin.css">
</head>
<body>
	<script language="javascript" src="login.js">
		</script>
	<div id="container">
		<div id="box">
			<div id="title_box">
				<label for="login" class="login"> Login Karunia</label>
			</div>
			<div id="body_box">	
				<form action="login_action.php" method="POST" accept-charset="utf-8" name="xform">
					<table> 
						<tbody>
							<tr>
								<td> <label for="username"> Username</label></td>
								<td> : </td>
								<td> <input type="text" name="username" placeholder="Masuka Username"> <br>	</td>
							</tr>
							<tr>	
								<td>  <label for="password"> Password</label>	</td>
								<td> : </td>
								<td>  <input type="password" name="password" placeholder="********"> </td>
							</tr>
							<tr>
								<td colspan="3">  <input type="submit" onclick="Submit()" name="submit" class="buttonr" value="Login" > <input type="reset" name="reset" class="buttons" value="Ulangi"> </td>
							</tr>
						</tbody>
					</table>	
				</form>
			</div>
		</div>
		
	</div>
</body>
</html>