<?php 
	session_start();
	if (empty($_SESSION['username'])) {
		header("location:index.php");
	}
 ?>
<html>
<head>
	<title> Gallery Karunia</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" href="stylegallery.css">
	<!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
	<style>
		
	</style>
</head>
<body>
<div id="container">
	<div id="box">
		<div id="title_box">
			<label for="login" class="gal"> Gallery Karunia</label>
		</div>
		<div id="body_box">	
			<div class="gallery">
			  <a target="_blank" href="img/img_fjords.jpg">
			    <img src="img/img_fjords.jpg" alt="Fjords" width="300" height="200">
			  </a>
			  <div class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ut tenetur hic, qui earum eligendi, aliquam labore mollitia veniam quod minus dolorum vel quam expedita facilis provident! Hic repellat laudantium magnam.</div>
			</div>

			<div class="gallery">
			  <a target="_blank" href="img/img_forest.jpg">
			    <img src="img/img_forest.jpg" alt="Forest" width="300" height="200">
			  </a>
			  <div class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum ut vero voluptates natus eos quo, consequatur, ipsum veritatis, neque similique doloremque iure suscipit voluptate culpa non! Nisi voluptatum provident voluptates.</div>
			</div>

			<div class="gallery">
			  <a target="_blank" href="img/img_lights.jpg">
			    <img src="img/img_lights.jpg" alt="Northern Lights" width="300" height="200">
			  </a>
			  <div class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores odit reprehenderit deserunt veritatis, qui quas obcaecati rem. Consequatur delectus quisquam debitis illo beatae, laborum placeat facere suscipit! In, ab, sequi.</div>
			</div>

			<div class="gallery">
			  <a target="_blank" href="img/img_mountains.jpg">
			    <img src="img/img_mountains.jpg" alt="Mountains" width="300" height="200">
			  </a>
			  <div class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit facilis optio architecto, adipisci cum natus. Corporis, explicabo, culpa sed quia, eveniet minima voluptas dolore a cumque tenetur eligendi ea natus!</div>
			</div>
			
			Back To <a href="dashboard.php">Dashboard</a>
			<!-- <div class="w3-content w3-section" id="gale" style="max-width:300px">
			  <img class="mySlides" src="img/img_fjords.jpg" style="width:100%">
			  <img class="mySlides" src="img/img_forest.jpg" style="width:100%">
			  <img class="mySlides" src="img/img_mountains.jpg" style="width:100%">
			</div> -->
		</div>
	</div>
</div>
<!-- <script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
} -->
</script>
</body>
</html>